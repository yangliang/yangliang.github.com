function [ W ] = sample_pair_overlaping( rlabels, labels, overlapping, percent, postive_para, negative_para )
nClass = length(rlabels);
nNode = length(labels);
W = zeros(nNode);
nPair_total = 0;
for i=1:nClass
    class_member = rlabels{1,i};
    class_member_single = setdiff(class_member,find(overlapping ~= 0));
    class_size = length(class_member_single);
    nPairs = class_size * (class_size - 1)/2;
    nPair_total = nPair_total + nPairs*2;
    nSelected = ceil(nPairs*percent);
    u = randperm(nPairs);
    u=u(1:nSelected);
    pairs = zeros(nSelected,2);
    index = 1;
    for p=1:class_size;
        for q=1:p-1
            pairs(index,:) = [p q];
            index = index + 1;
        end
    end
    paris = pairs(u,:);
    
    for j =1:nSelected
        pair = paris(j,:);
        a = class_member_single(pair(1));
        b = class_member_single(pair(2));
        W(a,b) = postive_para;
        W(b,a) = postive_para;
    end
    
end
sum(sum(W))/nPair_total;










% nNode = length(labels);
% nPair = nNode * (nNode-1)/2;
% W = zeros(nNode);
% for i=1:nPair*percent
%     u = randperm(nNode);
%     a = u(1,1);
%     b = u(1,2);
%     if (W(a,b) == 0)
%         if overlapping(a) == 0 && overlapping(b) == 0 && labels{a} == labels{b}
%             W(a,b) = postive_para;
%             W(b,a) = postive_para;
%         end
%     end
% end
% 
% sum(sum(W))/nPair


% nNode = size(labels,1);
% nPair = nNode * (nNode-1)/2;
% W = zeros(nNode);
% for i=1:nPair*percent
%     u = randperm(nNode);
%     a = u(1,1);
%     b = u(1,2);
%     if (W(a,b) == 0)
%         if testConnect(labels(a,:),labels(b,:)) && labels(b,2) == 0
%                 W(a,b) = postive_para;
%                 W(b,a) = postive_para;
%             
%             if labels(b,2) ~= 0;
%                 disp([num2str(a),'---',num2str(b)]);
%             end
%         else
%             W(a,b) = (-1)*negative_para;
%             W(b,a) = (-1)*negative_para;
%         end
%     end
% end

end


