clear;clc;
datasets = {'dolphins','karate','school6','school7','football','polbooks'};%,
 
dirname=cd;
addpath(fullfile(dirname,'starter'));
addpath(fullfile(dirname,'starter','minFunc'));
for i=1:length(datasets)
    dataset = datasets{i};
    community_detection(dataset,10, 1);
    load([ dataset]);
    [~,index] = max(modularity(:));
    perf = accurancy(index);
    bestperf = max(accurancy(:));
    disp([dataset '  best:' num2str(bestperf)   '   perf:' num2str(perf)]);
end