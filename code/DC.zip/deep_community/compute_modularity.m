function modularity = compute_modularity(modularity_matrix, community)
community_num = max(community);
node_num = length(community);
S = zeros(node_num,community_num);
for i=1:community_num
    S(find(community ==i),i) = 1;
end
modularity = trace(S'*modularity_matrix*S);