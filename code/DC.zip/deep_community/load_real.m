function [n, M, nClass, labels, rlabels] = load_real(dataset)

load(['mat_data' filesep 'real' filesep dataset '.mat']);

end