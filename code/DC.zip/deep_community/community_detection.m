function community_detection(dataset, nIter, batch, isSemi, ratio, gamma)
if nargin <= 2
    batch = 1;
end
if nargin <= 3
    isSemi = 0;
    ratio = 0;
    gamma = 0;
end
if isSemi == 1
    folder = num2str(gamma);
    mkdir(folder);
elseif isSemi == 2
    folder = ['kl_' num2str(gamma)];
    mkdir(folder);
end
disp(['dataset:' dataset  '  ratio:' num2str(ratio) '   gamma:' num2str(gamma) '   ' datestr(now)]);
[n, G, nClass, labels, rlabels] = load_file(dataset, 'real');
layer_size_set = [4096,2048,1024, 512, 256, 128, 64, 32, 16];
layer_size_set = [4096,2048,      512, 256, 128, 64, 32, 16];

layer_size_start = find(layer_size_set<n,1);
layers_size = [n, layer_size_set(layer_size_start:end)];
accurancy = zeros(length(layers_size)-1, nIter);
modularity = zeros(length(layers_size)-1, nIter);
error = zeros(length(layers_size)-1, nIter);
detail = cell(1,nIter);
for i=1:nIter
    %disp(['----round:' num2str(i) '   ' datestr(now)]);
    if ~isSemi
        detail{i} = deep_community(G, nClass, layers_size, batch);
    elseif isSemi == 1
        %W = sample_pair_overlaping( rlabels, labels, [], ratio ,1, 0 );
        W = sample_pair(labels,ratio);
        D = diag(sum(W,2));
        laplace = D - W;
        detail{i} = deep_community(G, nClass, layers_size, batch, isSemi, laplace, gamma);
    elseif isSemi == 2
        %W = sample_pair_overlaping( rlabels, labels, [], ratio ,1, 0 );
        W = sample_pair(labels,ratio);
        detail{i} = deep_community(G, nClass, layers_size, batch, isSemi, W, gamma);
    end
    for j=1:length(detail{i})
        modularity(j,i) = detail{i}{j}.modularity;
        error(j,i) = detail{i}{j}.error;
        accurancy(j,i)  = compute_NMI(labels,detail{i}{j}.community);
    end
    if ~isSemi
        save(dataset,'detail','modularity','accurancy','error');
    elseif isSemi == 1
        save([folder filesep dataset '_' num2str(ratio) '.mat'],'detail','modularity','accurancy','error');
    elseif isSemi == 2
        save([folder filesep dataset '_' num2str(ratio) '.mat'],'detail','modularity','accurancy','error');
    end
end
