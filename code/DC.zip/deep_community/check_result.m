clear;clc;
datasets = {'dolphins','karate','school6','school7','football','polbooks'};%,,'polblogs'
gamma_array = [0.1, 0.05,0.01, 0.005,0.001, 0.0005,0.0001, 0.00005,0.00001];
percent_array = 0.1:0.1:1;
nIter = 10;
iSemi = 1;

dirname=cd;
addpath(fullfile(dirname,'starter'));
addpath(fullfile(dirname,'starter','minFunc'));

for gamma = gamma_array
    folder = [num2str(gamma)];
    mkdir(folder);
    for i=1:length(datasets)
        dataset = datasets{i};
        for percent = percent_array
            load([folder filesep dataset  '_' num2str(percent) '.mat']);
            vec = sum(modularity);
            if length(find(vec == 0)) > 0
                disp([folder filesep dataset  '_' num2str(percent) '.mat']);
            end
%             [~,index] = max(modularity(:));
%             perf = accurancy(index);
%             bestperf = max(accurancy(:));
%             disp([dataset 'with percent' num2str(percent)  '  best:' num2str(bestperf)   '   perf:' num2str(perf)]);
        end
    end
end

% dataset = 'polblogs';
% [n, G, nClass, labels, rlabels] = load_file(dataset);
% W = sample_pair(labels,0.1);