clear;clc;
datasets = {'dolphins','karate','school6','school7','football','polbooks','polblogs'};%,

isSemi = 1 % l2 distance
isSemi = 2; %KL divergence


dirname=cd;
addpath(fullfile(dirname,'starter'));
addpath(fullfile(dirname,'starter','minFunc'));
gamma = 0.2;
for i=1:length(datasets)
    dataset = datasets{i};
    for j=0.5      %percent of embedding pairwise constraints
        
        if isSemi == 1
            folder = num2str(gamma);
        elseif isSemi == 2
            folder = ['kl_' num2str(gamma)];
        end
        community_detection(dataset,10, 1, isSemi, j, gamma);
        load([folder filesep dataset  '_' num2str(j) '.mat']);
        [~,index] = max(modularity(:));
        perf = accurancy(index);
        bestperf = max(accurancy(:));
        disp([dataset 'with percent' num2str(j)  '  best:' num2str(bestperf)   '   perf:' num2str(perf)]);
    end
end

