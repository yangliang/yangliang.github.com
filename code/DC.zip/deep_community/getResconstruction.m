function reconstruction = getResconstruction(weight, bias,  layers_num, hidden)
for layer=layers_num:-1:1
    hidden = sigmoid(bsxfun(@plus, weight{layer} * hidden, bias{layer}));
end
reconstruction = hidden;