function W = sample_pair(labels, percent)
community_num = max(labels);
node_num = length(labels);
W =  zeros(node_num);
pairs_all = 0;
pairs_selected = 0;
for i=1:community_num
    W_i = zeros(node_num);
    index_row = find(labels == i);
    W_i(index_row,index_row) = 1;
    W_i = W_i - tril(W_i);
    index_sub = find(W_i(:)==1);
    index_sort = randperm(length(index_sub));
    index_sort = index_sort(1:round(length(index_sub)*percent));
    index_sample = index_sub(index_sort);
    W_sub = zeros(node_num);
    W_sub(index_sample) = 1;
    W = W + W_sub;
    pairs_all = pairs_all + length(index_row)^2;
    pairs_selected = pairs_selected + length(find(W_sub == 1));
end
W = W + W';
%disp(['overall percent is: ', num2str(pairs_selected/pairs_all)]);