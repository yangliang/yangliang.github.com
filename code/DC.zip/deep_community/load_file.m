function [n, G, nClass, labels, rlabels] = load_file(dataset,type)
load(['mat_data' filesep 'real' filesep dataset '.mat']);
labels = labels_real;

end

