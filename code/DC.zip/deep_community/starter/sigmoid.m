function sigm = sigmoid(x)
  
    sigm = 1 ./ (1 + exp(-x));
end