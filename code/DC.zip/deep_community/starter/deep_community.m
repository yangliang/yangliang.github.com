function [detail] = deep_community(adjacency_matrix, community_num, layers_size, batch, isSemi, laplace, gamma)
if nargin <= 3
    batch = 1;
end
if nargin <= 4
    isSemi = 0;
    laplace = [];
    gamma = 0;
end
modularity_matrix =  adj2mod(adjacency_matrix);
% modularity_diag_inv = diag(1./sum(modularity_matrix));
% modularity_matrix = modularity_diag_inv*modularity_matrix;
input_data = modularity_matrix;
detail = cell(1,length(layers_size)-1);
weight = cell(length(layers_size)-1,1);
bias = cell(length(layers_size)-1,1);
for i=2:length(layers_size)
    %disp(['--------layer:' num2str(i-1) '   ' datestr(now)]);
    [W1, W2, b1, b2] = dl(input_data, layers_size(i-1), layers_size(i), batch, isSemi, laplace, gamma);
    [ainput, ahidden, aoutput] = getActivation(W1, W2, b1, b2, input_data);
    weight{i-1} = W2;
    bias{i-1} = b2;
    input_data = ahidden;
    output = input_data';
    reconstruction = getResconstruction(weight, bias,  i-1, ahidden);
    community = kmeans(output, community_num, 'EmptyAction', 'drop');
    %modularity = compute_modularity(modularity_matrix, community);
    modularity = compute_Q(adjacency_matrix, community);
    reconstructe_error = compute_error(modularity_matrix, reconstruction);
    detail{i-1}.layer = i;
    detail{i-1}.layer_size = layers_size(i);
    detail{i-1}.output = output;
    detail{i-1}.community = community;
    detail{i-1}.modularity = modularity;
    detail{i-1}.error = reconstructe_error;
end
