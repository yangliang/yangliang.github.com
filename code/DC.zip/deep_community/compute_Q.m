function Q=compute_Q(M,labels) 
d=sum(M,2)';
total=sum(d);
Q=0;
for i=1:max(labels)
    indexs=find(labels == i);
    [i1,j1,v1]=find(M(indexs,indexs));
    ei=length(i1)/total;
    Q=Q+ei;
    
    ai=sum(d(indexs))/total;
    ai=ai*ai;
    Q=Q-ai;
end 