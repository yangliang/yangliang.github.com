function reconstructe_error = compute_error(modularity_matrix, aoutput)
datasize = size(modularity_matrix, 2);
error_matrix = modularity_matrix - aoutput;
reconstructe_error = 0;
for i =1:datasize
    reconstructe_error = reconstructe_error + norm(error_matrix(i,:));
end
