function labels = reduced_modularity(adj_reduced,adj,clique,iso_num,c)
disp(['The number of cliques is ' num2str(length(clique)) ', and the number of communities is ' num2str(c) ' and the number of iso is ' num2str(iso_num)])
if length(clique) == c
    clique_label = 1:c;
elseif iso_num == c
    clique = random_merge_clique(adj,clique, c);
    clique_label = 1:c;
else
    adj_reduced = adj_reduced(1:end-iso_num,1:end-iso_num);
    %[clique_label,nClass] = weighted_modularity(adj_reduced, c-iso_num);
    clique_label = weighted_spectral(adj_reduced, c-iso_num);
    clique_label(end+1:length(clique)) = c-iso_num+1:c;
end
labels = expand_clique_label(clique_label, clique);
end

function clique = random_merge_clique(adj, clique, c)
    nClique = length(clique);
    for i=1:nClique - c
        num = zeros(1,nClique);
        for j=nClique - c+1:nClique
            num(j) = sum(sum(adj(clique{i},clique{j})));
        end
        [~,idx]= max(num)
        clique{idx} = [clique{idx}, clique{i}];
    end
    for i=1:nClique - c
        clique(i) = [];
    end
end