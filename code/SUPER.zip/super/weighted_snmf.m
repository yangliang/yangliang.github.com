function label = weighted_snmf(A, W, c)
T=20;
X=weighted_snmf_once(A,W, c,T);
S=convert3(X);
[~,label] = max(S,[],2);
end

function [mX,mi]=weighted_snmf_once(G,W, c,T)
L=1000;
epcl=1.0e-3;
mi=1.0e20;
n=size(G,1);
for t=1:T
    X=rand(n,c);
    gg=X*X';
    sav=sum(sum(abs(W.*(G-gg)).^2))^(1/2);
    for i=1:L
        X=X.*(((W.*G.*W')*X)./max((W.*(X*X').*W')*X,1e-10)).^(0.25);
        gg=X*X';
        cur=sum(sum(abs(W.*(G-gg)).^2))^(1/2);
        if abs(cur-sav)<epcl
            sav=cur;
            break;
        end
        sav=cur;
    end
    if sav<mi || t==1
        mi=sav;
        mX=X;
    end
end
end

function S=convert3(X)
b=sum(X,2);
c=size(X,2);
D=repmat(b, [1,c]);
S=X./D;
end