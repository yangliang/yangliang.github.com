function modularity_matrix =  adj2mod(adjacency_matrix)
degree = sum(adjacency_matrix);
edge_number = sum(degree)/2;
modularity_matrix = adjacency_matrix - degree'*degree./(2*edge_number);