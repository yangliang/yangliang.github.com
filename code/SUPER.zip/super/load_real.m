function [n, M, nClass, labels, rlabels] = load_real(dataset)
cd =['.' filesep 'data'  filesep ];

str1=[cd,dataset, '.dat']; %network filename
str2=[cd,dataset, '_rlabels.mat']; %network filename

load(str2);
n = length(labels);

A=load(str1);
m=size(A,1);
M=sparse(A(:,1),A(:,2),ones(m,1),n,n);
M=full(M);
M=M+M';
[x,y,z]=find(M);
M=[x,y];


nClass = max(labels);
rlabels = cell(1,nClass);
[Y,I] = sort(labels);
for i=1:nClass
    rlabels{1,i} = I(Y==i);
end

end