function labels = expand_clique_label(clique_label, clique)
k = max(unique(clique_label));
m = length(clique);
labels_cell = cell(1,k);
n = 0;
for i=1:m
    cmty = clique_label(i);
    labels_cell{cmty} = [labels_cell{cmty}, clique{i}];
    n = n + length(clique{i});
end
labels = zeros(1,n);
for i=1:k
    labels(labels_cell{i}) = i;
end




