function [adj_reduced,clique, isolated_num] = reduce_network(adj, ml, cl)
n = size(adj,1);
[~,clique] = mustlink_exhausive(ml);
%cl_exhausive = cannotlink__exhausive(ml_exhausive,cl);
c = length(clique);
node_in_clique = [];
for i=1:c
    node_in_clique = union(node_in_clique, clique{i});
end
n_in_clique = length(node_in_clique);
n_not_in_clique = n - n_in_clique;
node_not_in_clique = setdiff(1:n, node_in_clique);

for i=1:n_not_in_clique
    clique{end+1} = node_not_in_clique(i);
end

adj_reduced = compute_adj(clique, adj, cl);

ind = find(sum(adj_reduced>0)==0);
isolated = [];

if ~isempty(ind)
    for j=ind
        if j<=c
            isolated = [isolated, j];
        end
    end
    connected = setdiff(1:length(clique),isolated);
    clique = clique([connected,isolated]);
    adj_reduced = compute_adj(clique, adj, cl);
end
isolated_num = length(isolated);

% ind = sum(adj_reduced>0);
% 
% [i,j] = find(adj_reduced);
% clique_del_index = [];
% for k=1:length(i)
%     if ind(i(k)) == 1 && ind(j(k)) == 1 && i(k) < j(k)
%         clique{i(k)} = [clique{i(k)}, clique{j(k)}];
%         clique_del_index = [clique_del_index j(k)];
%     end
% end
% 
% for i=length(clique_del_index):-1:1
%     clique(clique_del_index(i)) = [];
% end
% 
% 
% if length(clique) ~= c
%     adj_reduced = compute_adj(clique, adj, cl);
% end

end


function adj_reduced = compute_adj(clique, adj, cl)
adj_reduced_size = length(clique);
adj_reduced = zeros(length(clique));
for i=1:adj_reduced_size
    for j=i+1:adj_reduced_size
        cl_sub = cl(clique{i},clique{j});
        adj_sub = adj(clique{i},clique{j});
        if sum(cl_sub(:)) > 0
            adj_reduced(i,j) = 0;
        else
            adj_reduced(i,j) = sum(adj_sub(:));
        end
    end
end
adj_reduced = adj_reduced + adj_reduced';
end

function clique = merge_clique(clique, list)
list_order = sort(list);
base = list_order(1);
for i=length(list_order):-1:2
    clique{base} = [clique{base}, clique{list_order(i)}];
    clique(list_order(i)) = [];
end
end