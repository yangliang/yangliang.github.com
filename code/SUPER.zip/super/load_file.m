function [n, G, nClass, labels, rlabels] = load_file(dataset, type, sample, subtype)

if strcmp(dataset, 'lfr') || strcmp(dataset, 'LFR')
    if nargin < 4 || isempty(subtype)
        subtype = '1k20100';
    end
    
    [n, M, nClass, labels, rlabels] = load_lfr(type, sample, subtype);
elseif strcmp(dataset, 'gn') || strcmp(dataset, 'GN')
    [n, M, nClass, labels, rlabels] = load_gn(type, sample);
elseif ~isempty(type) && (strcmp(type,'fb') || strcmp(type,'FB'))
    [n, M, nClass, labels, rlabels] = load_fb(dataset);
else
    [n, M, nClass, labels, rlabels] = load_real(dataset);
end

m2=size(M,1);
M=sparse(M(:,1),M(:,2),ones(m2,1));
G=full(M);

%[G, labels] = block_adj(G, labels);
end

