function [W_ML,W_CL] = uniform_pairwise_sample(N,Label,Select)
W_ML = zeros(N,N); W_CL = zeros(N,N);
NN = N*(N-1)/2;
if Select <=1
    Select = ceil(NN*Select);
end
a = zeros(2,NN);
temp = 1;
ran = randperm(NN);
for i = 1:(N-1)
    for j = (i+1):N
        a(:,ran(temp)) = [i,j];
        temp = temp+1;
    end
end
for iter = 1:Select
    if Label(a(1,iter))==Label(a(2,iter))
       W_ML(a(1,iter),a(2,iter)) = 1;
       W_ML(a(2,iter),a(1,iter)) = 1;
    else
       W_CL(a(1,iter),a(2,iter)) = 1;
       W_CL(a(2,iter),a(1,iter)) = 1;
    end
end



