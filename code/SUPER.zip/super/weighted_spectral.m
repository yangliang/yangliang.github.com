function label = weighted_spectral(adj,c)
modularity_matrix =  adj2mod(adj);
c
[Q, V] = eigs(modularity_matrix, c, 'LM');
label = kmeans(Q, c);






