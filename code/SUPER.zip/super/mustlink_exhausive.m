function [ml_exhausive,clique] = mustlink_exhausive(ml)
[i,j] = find(ml);

pairs_select = [i,j];
selection = size(pairs_select,1);

clique = {};
for i=1:selection
    pair = pairs_select(i,:);
    n1 = pair(1); n2 = pair(2);
    matching = 0;
    for j=1:length(clique)
        clique_j = clique{j};
        if any(clique_j == n1) || any(clique_j == n2)
            clique{j} = union(clique{j},[n1,n2]);
            matching = matching +1;
            if matching == 1
                j_one = j;
            else
                clique{j_one} = union(clique{j},clique{j_one});
                clique(j) = [];
                break;
            end
        end
    end
    if matching == 0
        clique{end+1} = [n1,n2];
    end
end

ml_exhausive = zeros(size(ml));
for i=1:length(clique)
    clique_i_index = clique{i};
    ml_exhausive(clique_i_index,clique_i_index) = 1;
end