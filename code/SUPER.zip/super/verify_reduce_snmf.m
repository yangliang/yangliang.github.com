clear;clc;
result_folder = './result';
percent_array = 0.01:0.01:0.1;
datasets = {'polbooks'};

for i=1:length(datasets)
    dataset = datasets{i};
    [n, G, nClass, labels, rlabels] = load_file(dataset, 'real');
    for percent = percent_array;
        for s = 1:10
            [W_ML,W_CL] = uniform_pairwise_sample(n,labels,percent);
            
            [adj_reduced,clique,iso_num] = reduce_network(G, W_ML, W_CL);
            tic;
            %labels_reduced = reduced_modularity(adj_reduced,G,clique,iso_num,nClass);
            labels_reduced = reduced_snmf(G, W_ML, W_CL, nClass);
            time_red = toc;
            accuracy_red=compute_NMI(labels,labels_reduced)
            
            
            G_constrained = (G + W_ML - W_CL > 0);
            tic;
            %labels_unreduced = weighted_spectral(G_constrained,nClass);
            labels_unreduced = weighted_snmf(G_constrained, ones(size(G_constrained)), nClass);
            time_unred = toc;
            accuracy_unred=compute_NMI(labels,labels_unreduced)
            
            filename = [dataset  '_' num2str(percent*100) '_' num2str(s)  '.mat'];
            save(fullfile(result_folder,filename),'time_red','accuracy_red','time_unred','accuracy_unred');
            
            pause(0.5)
        end
    end
end

